# y^2 TB Detection > 2025-11-06 8:04pm
https://universe.roboflow.com/syabar/y-2-tb-detection-2h5u4

Provided by a Roboflow user
License: CC BY 4.0

